package com.amazon.buspassmanagement.db;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
//import java.sql.Connection;
//import java.sql.DriverManager;
//import java.sql.ResultSet;
//import java.sql.Statement;
import java.sql.*;


// To connect and to execute SQL Statements in Database MySQL or MSSQL :)

/*
 	
 	JDBC Procedure:
 		1. Load the Driver
 			1.1 Add the DataBase Library in your project
 			1.2 Use API -> Class.forname
 		
 		2. Connect to DataBase
 			URL
 			Username
 			Password
 			API -> DriverManager.getConnection(....)
 			API -> Connection
 	
 		3. Execute SQL Query
 			API -> Using the API Statment
 		
 		4. Close Connection
 */

public class DB {
	
	private static DB db;
	private Connection connection;
	
	// Singleton Design Pattern
	private DB() {
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			//System.out.println("[DB] Driver Loaded..");
			createConnection();
		} catch (Exception e) {
			System.err.println("[DB] [Driver] Something Went Wrong: "+e);
		}
	}


	public void createConnection() {
		
		try {
			
			String url ="jdbc:sqlserver://localhost:1433;database=BusPass;user=sa;password=Deepali@27;trustServerCertificate=true";
			connection = DriverManager.getConnection(url);
			//System.out.println("Connection Created....");
		} catch (Exception e) {
			System.err.println("[connection]Something Went Wrong: "+e);
		}	
	}


	// Use of Singleton Design Pattern
    public static DB getInstance() {
        if(db == null) {
            db = new DB();
        }

        return db;
    }
    
    public int executeSQL(String sql) {
		
		int result = 0;
		
		try {
			// Create Statement to execute SQL from Java Application
			Statement stmt = connection.createStatement();
			// executeUpdate can be used to perform DML operation - Insert/Update/Delete
			result = stmt.executeUpdate(sql);
			//System.out.println("[DB] SQL Statement Executed...");
		} catch (Exception e) {
			System.err.println("[DB] [Execute SQL] Something Went Wrong: "+e);
		}
		
		return result;
	}
	
	public ResultSet executeRetrieveQuery(String sql) {
		
		// ResultSet holds Table Data
		ResultSet set = null;
		
		try {
			// Create Statement to execute SQL from Java Application
			Statement stmt = connection.createStatement();
			
			// For Select Statement
			// Here executeQuery -> Returns a ResultSet which shall have all the rows of the table
			set = stmt.executeQuery(sql);
			
			//System.out.println("[DB] SQL Statement Executed...");
		} catch (Exception e) {
			System.err.println("[DB] [Execute SQL] Something Went Wrong: "+e);
		}
		
		return set;
		
	}
	
	public void closeConnection() {
		try {
			connection.close();
			//System.out.println("[DB] Connection Closed..");
		} catch (Exception e) {
			System.err.println("[DB] [Connection] Something Went Wrong: "+e);
		}
	}
	
}
