/**
 * 
 */
/**
 * @author kedeepal
 *
 */
module BusPassTesting {
	requires java.sql;
	requires java.desktop;
}